from bs4 import BeautifulSoup
import requests, re

def remove_some_special_tags(raw_html_data):

    scripts = re.compile(r'<(script).*?</\1>(?s)')
    css = re.compile(r'<style.*?/style>')
    comments = re.compile(r"<!--(.|\s|\n)*?-->")

    text = scripts.sub('', raw_html_data.lstrip("<!doctype html>"))
    text = css.sub('', text)
    text = comments.sub('', text)

    return text

url = "https://stackoverflow.com/"
response = requests.get(url, headers=headers)
raw_data = str(response.content, encoding="utf-8")

html_beauty = remove_some_special_tags(raw_data)

soup = BeautifulSoup(html_beauty, 'html.parser')

for link in soup.findAll(class_='question-hyperlink'):
    print(link.text)
    print("\n")
